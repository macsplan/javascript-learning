$(document).ready(function(){
	var savingsGoal;
	var savingsGoalAmt;
	var goalMth;
	var goalYear;
	var currentSavings;
	var monthlyContributions;
	var currentDate = new Date();
	var currentMth = currentDate.getMonth();
	var currentYear = currentDate.getFullYear();
	var finalResult;
	var monthsToSave;
	var ammountSavedMontly;
	var monthNames = ["Jan", "Feb", "March", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

	function calMonths() {
		if(currentMth === 0){ //Have to take into account
			currentMth++;
			goalMth++;
		}
		numberOfMonths = (goalYear - currentYear) * 12 + (goalMth - currentMth);
		return numberOfMonths;
	};


	function calAmmountSavedMontly() {
		return ammountSavedMontly = monthsToSave * monthlyContributions;
	};

	function calCheckSaving() {
	 return	currentSavings = parseFloat(currentSavings) + parseFloat(ammountSavedMontly)
	};


	function checkSavingGoal() {
		if (currentSavings === savingsGoalAmt) {
			finalResult = "You Saved your Goal";
		} else if (currentSavings > savingsGoalAmt){
			finalResult = "Congralations you exceeded your goal";
		} else {
			finalResult = "I'm sorry you didn't make your goal";
		}
		return finalResult;
	};

	$('#savingsForm').submit(function(e){
		e.preventDefault();
		savingsGoal = $("input[name='savingsGoal']").val();
		savingsGoalAmt = $("input[name='savingsGoalAmt']").val();
		goalMth = $("select[name=month]").val();
		goalYear = $("input[name='year']").val();
		currentSavings = $("input[name='currentSavings']").val();
		monthlyContributions = $("input[name='monthlyContributions']").val();
		monthsToSave = calMonths();
		ammountSavedMontly = calAmmountSavedMontly();

		var filledIn = true;
		$('input').each(function() {
	    if ($(this).val() == "") {
				filledIn = false;
	    }
	  });

		if (!filledIn) {
			alert("Please fill in the input boxes")
		}
		else if (goalYear <= currentYear) {
			alert("Please choose a future year")
		}
		else {
			print();
		}

	 	function print() {
	 		$('#results').html( "<p>Your are saving for a " +
				savingsGoal + "</p>\n<p>Your Saving Goal Period is " +
				monthNames[currentMth] + ", " + currentYear +
			 	" to " + monthNames[goalMth] + ", " + goalYear +
				"</p>\n<p> you will save $" + calCheckSaving() + " over the next " +
				monthsToSave + " months</p>\n<p>" + checkSavingGoal() +
				" of $" + savingsGoalAmt + "</p>");
	 	};
	});

	// 1. fill in form
	// 2. get number of months between

});




// step 2 process the data

// step 3 return the results to the front-end
